package com.rustero.core.effects;

import android.opengl.GLES20;
import android.opengl.Matrix;

import com.rustero.App;
import com.rustero.core.egl.glCore;
import com.rustero.core.egl.glScene;
import com.rustero.gadgets.Size2;

import java.util.ArrayList;
import java.util.List;


public class


glEffect extends glScene {


	public static final String TYPE_BlackAndWhite = "Black&White";
    public static final String TYPE_Sepia = "Sepia";
    public static final String TYPE_Sharpen = "Sharpen";
    public static final String TYPE_EdgeDetection = "Edge detection";
    public static final String TYPE_Embossing = "Embossing";

	public static final String TYPE_Mirror = "Mirror";
	public static final String TYPE_Swirl = "Swirl";
	public static final String TYPE_Bulge = "Bulge";
	public static final String TYPE_Pinch = "Pinch";



	public String type = "";
	public Size2 mSize = new Size2(1, 1);

	private static List<String> mKnown = new ArrayList<>();




	public static glEffect createEffect(String aName) {
		glEffect effect = null;
		switch (aName) {
			case glEffect.TYPE_BlackAndWhite:
				effect = new glEffectBlackAndWhite();
				break;
			case glEffect.TYPE_Sepia:
				effect = new glEffectSepia();
				break;
			case glEffect.TYPE_Sharpen:
				effect = new glEffectSharpen();
				break;
			case glEffect.TYPE_EdgeDetection:
				effect = new glEffectEdgeDetection();
				break;
			case glEffect.TYPE_Embossing:
				effect = new glEffectEmbossing();
				break;
			case glEffect.TYPE_Mirror:
				effect = new glEffectMirror();
				break;
			case glEffect.TYPE_Swirl:
				effect = new glEffectSwirl();
				break;
			case glEffect.TYPE_Bulge:
				effect = new glEffectBulge();
				break;
			case glEffect.TYPE_Pinch:
				effect = new glEffectPinch();
				break;
			default:
				App.log("no filter");
		}
		return effect;
	}



	public static List<String> getmKnown() {
		return mKnown;
	}



    public glEffect() {
        super(false);
        mVertexBuffer = FULL_RECTANGLE_BUF;
        mVertexCount = 4;
        mCoordsPerVertex = 2;
        mVertexStride = 8;
        mTexBuffer = FULL_RECTANGLE_TEX_BUF;
        mTexStride = 8;

        texMatrix = new float[16];
        Matrix.setIdentityM(texMatrix, 0);

        mvpMatrix = new float[16];
        Matrix.setIdentityM(mvpMatrix, 0);

		mKnown.add(TYPE_BlackAndWhite);
		mKnown.add(TYPE_Sepia);
		mKnown.add(TYPE_Sharpen);
		mKnown.add(TYPE_EdgeDetection);
		mKnown.add(TYPE_Embossing);

		mKnown.add(TYPE_Mirror);
		mKnown.add(TYPE_Swirl);
		mKnown.add(TYPE_Bulge);
		mKnown.add(TYPE_Pinch);
    }



    public void release() {
        App.log("release");

        if (mProgram > 0) {
            GLES20.glDeleteProgram(mProgram);
            mProgram = 0;
        }
    }



    public int createProgram(String vertexSource, String fragmentSource) {
        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSource);
        if (vertexShader == 0) {
            return 0;
        }
        int pixelShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource);
        if (pixelShader == 0) {
            return 0;
        }

        int program = GLES20.glCreateProgram();
        glCore.checkGlError("glCreateProgram");
        if (program == 0) {
            App.log("Could not create program");
        }
        GLES20.glAttachShader(program, vertexShader);
        glCore.checkGlError("glAttachShader");
        GLES20.glAttachShader(program, pixelShader);
        glCore.checkGlError("glAttachShader");
        GLES20.glLinkProgram(program);
        int[] linkStatus = new int[1];
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0);
        if (linkStatus[0] != GLES20.GL_TRUE) {
            App.log("Could not link program: ");
            App.log(GLES20.glGetProgramInfoLog(program));
            GLES20.glDeleteProgram(program);
            program = 0;
        }
        return program;
    }



    // Compiles the provided shader source.
    protected int loadShader(int shaderType, String source) {
        int shader = GLES20.glCreateShader(shaderType);
        glCore.checkGlError("glCreateShader type=" + shaderType);
        GLES20.glShaderSource(shader, source);
        GLES20.glCompileShader(shader);
        int[] compiled = new int[1];
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0);
        if (compiled[0] == 0) {
            App.log("Could not compile shader " + shaderType + ":");
            App.log(" " + GLES20.glGetShaderInfoLog(shader));
            GLES20.glDeleteShader(shader);
            shader = 0;
        }
        return shader;
    }




    protected void compileShaders() {

        if (mExternal) {
            mFragmentCode = "#extension GL_OES_EGL_image_external : require\n" +
                "uniform samplerExternalOES sTexture;\n" +
                mFragmentCode;
        } else {
            mFragmentCode = "uniform sampler2D sTexture;\n" +
                mFragmentCode;
        }

        mProgram = createProgram(mVertexCode, mFragmentCode);
        if (mProgram == 0) {
            throw new RuntimeException("Unable to create program");
        }
        App.log("Created program " + mProgram + " (" + mProgram + ")");

        // get locations of attributes and uniforms
        mPositionLoc = GLES20.glGetAttribLocation(mProgram, "aPosition");
        checkLocation(mPositionLoc, "aPosition");

        mTextureCoordLoc = GLES20.glGetAttribLocation(mProgram, "aTextureCoord");
        checkLocation(mTextureCoordLoc, "aTextureCoord");

        mMVPMatrixLoc = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        checkLocation(mMVPMatrixLoc, "uMVPMatrix");

        mTexMatrixLoc = GLES20.glGetUniformLocation(mProgram, "uTexMatrix");
        checkLocation(mTexMatrixLoc, "uTexMatrix");

		compileCustom();
    }



	//customize in descendents
	protected void compileCustom() {
	}



    // Sets the size of the texture.  This is used to find adjacent texels when filtering.
    public void resize(Size2 aSize) {
		mSize = new Size2(aSize);
		resizeCustom();
    }


	//customize in descendents
	protected void resizeCustom() {
	}




    // Draws a viewport-filling rect, texturing it with the specified texture object.
    public void draw() {
        //set the target
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, helperStage.getFrambufId());

        // set the source
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, sourceStage.getTextureId());

        // Select the program.
        GLES20.glUseProgram(mProgram);
        glCore.checkGlError("glUseProgram");

        // Copy the model / view / projection matrix over.
        GLES20.glUniformMatrix4fv(mMVPMatrixLoc, 1, false, mvpMatrix, 0);
        glCore.checkGlError("glUniformMatrix4fv");

        // Copy the texture transformation matrix over.
        GLES20.glUniformMatrix4fv(mTexMatrixLoc, 1, false, texMatrix, 0);
        glCore.checkGlError("glUniformMatrix4fv");

        // Enable the "aPosition" vertex attribute.
        GLES20.glEnableVertexAttribArray(mPositionLoc);
        glCore.checkGlError("glEnableVertexAttribArray");

        // Connect VertexBuffer to "aPosition".
        GLES20.glVertexAttribPointer(mPositionLoc, mCoordsPerVertex, GLES20.GL_FLOAT, false, mVertexStride, mVertexBuffer);
        glCore.checkGlError("glVertexAttribPointer");

        // Enable the "aTextureCoord" vertex attribute.
        GLES20.glEnableVertexAttribArray(mTextureCoordLoc);
        glCore.checkGlError("glEnableVertexAttribArray");

        // Connect mTexBuffer to "aTextureCoord".
        GLES20.glVertexAttribPointer(mTextureCoordLoc, 2, GLES20.GL_FLOAT, false, mTexStride, mTexBuffer);
        glCore.checkGlError("glVertexAttribPointer");

		drawCustom();

        // Draw the rect.
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, mVertexCount);
        glCore.checkGlError("glDrawArrays");

        // Done -- disable vertex array, texture, and program.
        GLES20.glDisableVertexAttribArray(mPositionLoc);
        GLES20.glDisableVertexAttribArray(mTextureCoordLoc);

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);

        GLES20.glUseProgram(0);
        glCore.checkGlError("glEffect-draw-finish");

        outputStage = helperStage;
    }



	//customize in descendents
	protected void drawCustom() {
	}


}


package com.rustero.core.effects;


public class glEffectMirror extends glEffect {



	protected String getFragmentCode() {
		String result =
			"precision mediump float;\n" +
			"varying vec2 vTextureCoord;" +
			"void main() {" +
			"    vec2 position = vTextureCoord;" +
			"    position.x = 0.5 - abs(position.x - 0.5);" +
			"    vec4 pixel = texture2D(sTexture, position);" +
			"    gl_FragColor = pixel;" +
           	"}";

	return result;
}



    public glEffectMirror() {
        super();
		type = TYPE_Mirror;
    }






}

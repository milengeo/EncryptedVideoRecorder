
package com.rustero.core.effects;


import android.opengl.GLES20;
import android.util.Log;

import com.rustero.core.egl.glCore;
import com.rustero.gadgets.Size2;


public class glEffectBoxBlur_ex extends glEffect {
    private static final String LOG_TAG = "glEffectBoxBlur_ex";



    static String VertexCode1 =
		"uniform mat4 uMVPMatrix;\n" +
		"uniform mat4 uTexMatrix;\n" +
		"attribute vec4 aPosition;\n" +
		"attribute vec4 aTextureCoord;\n" +
		"varying vec2 vTextureCoord;\n" +
		"void main() {\n" +
		"    gl_Position = uMVPMatrix * aPosition;\n" +
		"    vTextureCoord = (uTexMatrix * aTextureCoord).xy;\n" +
		"}\n";



    static String FragmentCode1 =
		"precision mediump float;\n" +
		"uniform float texelWidthOffset; \n" +
		"uniform float texelHeightOffset; \n" +
		"varying mediump vec2 vTextureCoord;\n" +
		"const float weight = 1.0/13.0;\n" +
		"\n" +
		"void main() {\n" +
		"\n" +
			"vec2 step1 = vec2(1.5 * texelWidthOffset, 0.);\n" +
			"vec2 step2 = vec2(3.5 * texelWidthOffset, 0.);\n" +
			"vec2 step3 = vec2(5.5 * texelWidthOffset, 0.);\n" +
			"vec2 step4 = vec2(7.5 * texelWidthOffset, 0.);\n" +
			"vec2 step5 = vec2(9.5 * texelWidthOffset, 0.);\n" +
			"vec2 step6 = vec2(11.5 * texelWidthOffset, 0.);\n" +
			"\n" +
			"vec4 fragmentColor = texture2D(sTexture, vTextureCoord) * weight;\n" +

			"fragmentColor += texture2D(sTexture, vTextureCoord - step1) * weight;\n" +
			"fragmentColor += texture2D(sTexture, vTextureCoord + step1) * weight;\n" +
			"fragmentColor += texture2D(sTexture, vTextureCoord - step2) * weight;\n" +
			"fragmentColor += texture2D(sTexture, vTextureCoord + step2) * weight;\n" +

			"fragmentColor += texture2D(sTexture, vTextureCoord - step3) * weight;\n" +
			"fragmentColor += texture2D(sTexture, vTextureCoord + step3) * weight;\n" +
			"fragmentColor += texture2D(sTexture, vTextureCoord - step4) * weight;\n" +
			"fragmentColor += texture2D(sTexture, vTextureCoord + step4) * weight;\n" +

			"fragmentColor += texture2D(sTexture, vTextureCoord - step5) * weight;\n" +
			"fragmentColor += texture2D(sTexture, vTextureCoord + step5) * weight;\n" +
			"fragmentColor += texture2D(sTexture, vTextureCoord - step6) * weight;\n" +
			"fragmentColor += texture2D(sTexture, vTextureCoord + step6) * weight;\n" +

			"gl_FragColor = fragmentColor;\n" +
		"}\n";




	// * coordinate calculations in fragment


	static String VertexCode2 =
		"uniform mat4 uMVPMatrix;\n" +
		"uniform mat4 uTexMatrix;\n" +
		"attribute vec4 aPosition;\n" +
		"attribute vec4 aTextureCoord;\n" +
		"varying vec2 vTextureCoord;\n" +

		"void main() {\n" +
			"gl_Position = uMVPMatrix * aPosition;\n" +
			"vTextureCoord = (uTexMatrix * aTextureCoord).xy;\n" +
		"}\n";


    static String FragmentCode2 =
		"precision mediump float;\n" +
		"uniform sampler2D sTexture;\n" +
		"uniform float texelWidthOffset; \n" +
		"uniform float texelHeightOffset; \n" +
		"varying vec2 vTextureCoord;\n" +

		"const float weight = 1.0/13.0;\n" +
		"\n" +
		"void main() {\n" +
				"vec2 step1 = vec2(0., 1.5 * texelHeightOffset);\n" +
				"vec2 step2 = vec2(0., 3.5 * texelHeightOffset);\n" +
				"vec2 step3 = vec2(0., 5.5 * texelHeightOffset);\n" +
				"vec2 step4 = vec2(0., 7.5 * texelHeightOffset);\n" +
				"vec2 step5 = vec2(0., 9.5 * texelHeightOffset);\n" +
				"vec2 step6 = vec2(0., 11.5 * texelHeightOffset);\n" +
				"\n" +
				"vec4 fragmentColor = texture2D(sTexture, vTextureCoord) * weight;\n" +

				"fragmentColor += texture2D(sTexture, vTextureCoord - step1) * weight;\n" +
				"fragmentColor += texture2D(sTexture, vTextureCoord + step1) * weight;\n" +
				"fragmentColor += texture2D(sTexture, vTextureCoord - step2) * weight;\n" +
				"fragmentColor += texture2D(sTexture, vTextureCoord + step2) * weight;\n" +

				"fragmentColor += texture2D(sTexture, vTextureCoord - step3) * weight;\n" +
				"fragmentColor += texture2D(sTexture, vTextureCoord + step3) * weight;\n" +
				"fragmentColor += texture2D(sTexture, vTextureCoord - step4) * weight;\n" +
				"fragmentColor += texture2D(sTexture, vTextureCoord + step4) * weight;\n" +

				"fragmentColor += texture2D(sTexture, vTextureCoord - step5) * weight;\n" +
				"fragmentColor += texture2D(sTexture, vTextureCoord + step5) * weight;\n" +
				"fragmentColor += texture2D(sTexture, vTextureCoord - step6) * weight;\n" +
				"fragmentColor += texture2D(sTexture, vTextureCoord + step6) * weight;\n" +

				"gl_FragColor = fragmentColor;\n" +
		"}\n";














    private float mTexelWidthOffset, mTexelHeightOffset;
    private int mTexelWidthOffsetLoc1, mTexelHeightOffsetLoc1;
    private int mTexelWidthOffsetLoc2, mTexelHeightOffsetLoc2;


    // second stage
    protected int mProgram2;
    protected int mMVPMatrixLoc2;
    protected int mTexMatrixLoc2;
    protected int mPositionLoc2;
    protected int mTextureCoordLoc2;


    public glEffectBoxBlur_ex() {
		super();
//		type = Blur;
    }



    public void release() {
        Log.d(LOG_TAG, "release");
        super.release();

        if (mProgram2 > 0) {
            GLES20.glDeleteProgram(mProgram2);
            mProgram2 = 0;
        }
    }



    public void compile() {

        if (mExternal) {
            FragmentCode1 = "#extension GL_OES_EGL_image_external : require\n" +
                "uniform samplerExternalOES sTexture;\n" +
                FragmentCode1;
        } else {
            FragmentCode1 = "uniform sampler2D sTexture;\n" +
                FragmentCode1;
        }

        // first shader, horizontal
        mProgram = createProgram(VertexCode1, FragmentCode1);
        if (mProgram == 0) throw new RuntimeException("Unable to create program");
        mPositionLoc = GLES20.glGetAttribLocation(mProgram, "aPosition");
        mTextureCoordLoc = GLES20.glGetAttribLocation(mProgram, "aTextureCoord");
        mMVPMatrixLoc = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        mTexMatrixLoc = GLES20.glGetUniformLocation(mProgram, "uTexMatrix");

        mTexelWidthOffsetLoc1 = GLES20.glGetUniformLocation(mProgram, "texelWidthOffset");
        if (mTexelWidthOffsetLoc1 >= 0)
            checkLocation(mTexelWidthOffsetLoc1, "texelWidthOffset");
        mTexelHeightOffsetLoc1 = GLES20.glGetUniformLocation(mProgram, "texelHeightOffset");
        if (mTexelHeightOffsetLoc1 >= 0)
            checkLocation(mTexelHeightOffsetLoc1, "texelHeightOffset");

        // second shader, vertical
        mProgram2 = createProgram(VertexCode2, FragmentCode2);
        if (mProgram2 == 0) throw new RuntimeException("Unable to create program");
        mPositionLoc2 = GLES20.glGetAttribLocation(mProgram2, "aPosition");
        mTextureCoordLoc2 = GLES20.glGetAttribLocation(mProgram2, "aTextureCoord");
        if (mMVPMatrixLoc2 >= 0)
            mMVPMatrixLoc2 = GLES20.glGetUniformLocation(mProgram2, "uMVPMatrix");
        if (mTexMatrixLoc2 >= 0)
            mTexMatrixLoc2 = GLES20.glGetUniformLocation(mProgram2, "uTexMatrix");

        mTexelWidthOffsetLoc2 = GLES20.glGetUniformLocation(mProgram2, "texelWidthOffset");
        if (mTexelWidthOffsetLoc2 >= 0)
            checkLocation(mTexelWidthOffsetLoc2, "texelWidthOffset");
        mTexelHeightOffsetLoc2 = GLES20.glGetUniformLocation(mProgram2, "texelHeightOffset");
        if (mTexelHeightOffsetLoc2 >= 0)
            checkLocation(mTexelHeightOffsetLoc2, "texelHeightOffset");

    }



	public void resize(Size2 aSize) {
        super.resize(aSize);
        mTexelWidthOffset = 1.0f / mSize.x;
        mTexelHeightOffset = 1.0f / mSize.y;
    }





    public void draw() {

        // * first stage, horizontal

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, helperStage.getFrambufId());

        GLES20.glClearColor(0, 0, 0, 0);
        GLES20.glUseProgram(mProgram);
        GLES20.glDepthMask(false);

        // set the texture
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, sourceStage.getTextureId());

        GLES20.glUniformMatrix4fv(mMVPMatrixLoc, 1, false, glCore.IDENTITY_MATRIX, 0);
        GLES20.glUniformMatrix4fv(mTexMatrixLoc, 1, false, texMatrix, 0);
        GLES20.glEnableVertexAttribArray(mPositionLoc);
        GLES20.glVertexAttribPointer(mPositionLoc, mCoordsPerVertex, GLES20.GL_FLOAT, false, mVertexStride, mVertexBuffer);
        GLES20.glEnableVertexAttribArray(mTextureCoordLoc);
        GLES20.glVertexAttribPointer(mTextureCoordLoc, 2, GLES20.GL_FLOAT, false, mTexStride, mTexBuffer);

        if (mTexelWidthOffsetLoc1 >= 0)
            GLES20.glUniform1f(mTexelWidthOffsetLoc1, mTexelWidthOffset);
        if (mTexelHeightOffsetLoc1 >= 0)
            GLES20.glUniform1f(mTexelHeightOffsetLoc1, 0.0f);

        // Draw the rect.
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, mVertexCount);

        // Done -- disable vertex array, texture, and program.
        GLES20.glDisableVertexAttribArray(mPositionLoc);
        GLES20.glDisableVertexAttribArray(mTextureCoordLoc);

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);

        GLES20.glUseProgram(0);
        glCore.checkGlError("camera stage finish");


        // * second stage, vertical

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, sourceStage.getFrambufId());

        GLES20.glDepthMask(false);
        GLES20.glClearColor(0, 0, 0, 0);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

        GLES20.glUseProgram(mProgram2);
        glCore.checkGlError("glUseProgram");

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, helperStage.getTextureId());

        if (mMVPMatrixLoc2 >= 0)
            GLES20.glUniformMatrix4fv(mMVPMatrixLoc2, 1, false, glCore.IDENTITY_MATRIX, 0);
        if (mTexMatrixLoc2 >= 0)
            GLES20.glUniformMatrix4fv(mTexMatrixLoc2, 1, false, glCore.IDENTITY_MATRIX, 0);
        GLES20.glEnableVertexAttribArray(mPositionLoc2);
        GLES20.glVertexAttribPointer(mPositionLoc2, mCoordsPerVertex, GLES20.GL_FLOAT, false, mVertexStride, mVertexBuffer);
        GLES20.glEnableVertexAttribArray(mTextureCoordLoc2);
        GLES20.glVertexAttribPointer(mTextureCoordLoc2, 2, GLES20.GL_FLOAT, false, mTexStride, mTexBuffer);

        if (mTexelWidthOffsetLoc2 >= 0)
            GLES20.glUniform1f(mTexelWidthOffsetLoc2, 0.0f);
        if (mTexelHeightOffsetLoc2 >= 0)
            GLES20.glUniform1f(mTexelHeightOffsetLoc2, mTexelHeightOffset);

        // Draw the rect.
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, mVertexCount);

        // Done -- disable vertex array, texture, and program.
        GLES20.glDisableVertexAttribArray(mPositionLoc2);
        GLES20.glDisableVertexAttribArray(mTextureCoordLoc2);

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);

        GLES20.glUseProgram(0);
        glCore.checkGlError("blur second stage finish");

        outputStage = sourceStage;
    }


}
